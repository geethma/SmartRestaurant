	<?php  include 'Controller.php';?>
	<style>
	.cart-box {
    background-color: red;
    padding: -3px 0px 0px 0px;
    position: absolute;
    top: 0px;
    width: 113px;
    padding: 37px 31px 51px 0px;
    border-radius: 0px 0px 21px 19px;
}

.cart-box p.cart-totale {
    color: white;
    position: absolute;
    font-size: 18px;
    top: 44px;
    width: 100%;
   
    text-align: center;
	font-family: "Josefin Sans", Arial, sans-serif;
}

.cart-box span {
    position: absolute;
    color: white;
    top: 10px;
    font-size: 28px;
    width: 100%;
    text-align: center;
}
p.cart-qt {
    font-size: 15px;
    position: absolute;
    top: -7px;
    right: 31px;
    width: 18px;
    height: 18px;
    background-color: black;
    border-radius: 7px;
    text-align: center;
}
	</style>
	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
		    <a class="navbar-brand" href="index.php"><span class="flaticon-pizza-1 mr-1"></span>Smart<br><small>Restaurant</small></a>
		    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
		      <span class="icon icon-menu"></span> Menu
		    </button>
			<div class="collapse navbar-collapse" id="ftco-nav">
	            <ul class="navbar-nav ml-auto">
	                <li class="nav-item"><a href="Orders.php" class="nav-link">Orders</a></li>
				    <li class="nav-item"><a href="FoodItemsUI.php" class="nav-link">Food Items</a></li>
				    <li class="nav-item"><a href="ViewImage.php" class="nav-link">View Foods</a></li>
	                <?php 
					//echo 'aaaa -  '.$_SESSION['UserRoleID'];
					if($_SESSION['UserRoleID']!='1'){
						//echo 'bbbb';
						header("Location: Registration.php");
					}
					if(isset($_SESSION['UserRoleID'])!=''){
						if($_SESSION['UserRoleID']=='1'){
							?>
							   <li class="nav-item">
									<a class="nav-link" href="Orders.php"><i class="fa fa-user"> </i><?php echo $_SESSION['Username'];?></a>
								</li>
							<?php
						}else{
							?>
							   <li class="nav-item">
									<a class="nav-link"><i class="fa fa-user"> </i> <?php echo $_SESSION['Username'];?></a>
								</li>
							<?php
						}
						?>
						<li class="nav-item">
								<a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"> </i>Logout</a>
						</li>
						<?php
					}else{
						?>
						<li class="nav-item">
								<a class="nav-link" href="Registration.php"><i class="fas fa-sign-in-alt"> </i>Login</a>
						</li>
						<?php
					}
					?>
		        </ul>
	        </div>
		</div>
	</nav>