<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	<div class="container">
		<a class="navbar-brand" href="index.php"><span class="flaticon-pizza-1 mr-1"></span>Smart<br><small>Restaurant</small></a>
		<span class="cart-box-mobite">
			<a href="checkout.php">
				<?php 
				if(isset($_SESSION["item_total"])){
					?> <div class="cart-box" style="display:block"><?php
				}else{
					?> <div class="cart-box" style="display:none"><?php
				}
				?>
					
				<P class="cart-totale totale">
				<?php 
				if(isset($_SESSION["item_total"])){
					echo 'Rs '.number_format($_SESSION["item_total"],2);
				}else{
					echo 'Rs 00.00 ';
				}
				?>
				</P>
				<span class="icon-shopping-cart"><p class="cart-qt"><?php  if(isset($_SESSION["item_Qty"])){ echo $_SESSION["item_Qty"]; }?></p></span>
				</div>
			</a>
		</span>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
		   <span class="icon icon-menu"></span> Menu </button>
		<div class="collapse navbar-collapse" id="ftco-nav">
			<ul class="navbar-nav ml-auto">
			    <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
				<li class="nav-item"><a href="About.php" class="nav-link">About Us</a></li>
				<li class="nav-item"><a href="customerfeedbacks.php" class="nav-link">Customers Feedback</a></li>
					<?php 
					if(isset($_SESSION['UserRoleID'])!=''){
						if($_SESSION['UserRoleID']=='1'){
							?>
							   <li class="nav-item">
									<a class="nav-link" href="Orders.php"><i class="fa fa-user"> </i><?php echo $_SESSION['Username'];?></a>
								</li>
							<?php
						}else{
							?>
							<li class="nav-item">
								<a class="nav-link" href="#"><i class="fa fa-user"> </i> <?php echo $_SESSION['Username'];?></a>
							</li>
							<?php
						}
						?>
							<li class="nav-item">
								<a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"> </i>Logout</a>
							</li>
						<?php
					}else{
						if(isset( $_SESSION['Username'])!=''){
						?>
						<li class="nav-item">
							<a class="nav-link" href="checkout.php"><i class="fa fa-user"> </i>
							   <?php 
								
									echo   $_SESSION['Username'];
								?>
							</a>
						</li>
						<?php
						}
						?>
						<li class="nav-item">
							<a class="nav-link" href="Registration.php"><i class="fas fa-sign-in-alt"> </i>Login</a>
						</li>
						<?php
					}
					

					?>
				<li class="nav-item cart-box-desktop">
					<a href="checkout.php">
						<?php 
						if(isset($_SESSION["item_total"])){
							?>
							<div class="cart-box" style="display:block"><?php
						}else{
							?> 
							<div class="cart-box" style="display:none"><?php
						}
						?>
							<P class="cart-totale totale">
							<?php 
							if(isset($_SESSION["item_total"])){
								echo 'Rs '.number_format($_SESSION["item_total"],2);
							}else{
								echo 'Rs 00.00 ';
							}
							?>
							</P>
							<span class="icon-shopping-cart"><p class="cart-qt"><?php  if(isset($_SESSION["item_Qty"])){ echo $_SESSION["item_Qty"]; }?></p></span>
						</div>
					</a>
				</li>
			</ul>
		</div>
	</div>
</nav>