<?php
class ClassLoading
{
	public function Select_FoodItemsMain($CategoryID,$FoodType)
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfoodmenuitem` WHERE `FoodCatID`='".$CategoryID."' AND `FoodType`='".$FoodType."' ";
		$Result_FoodItems = $db_handle->runQuery($query);
		return $Result_FoodItems;
	}
	public function Select_FoodItemsMain2($SubFoodID)
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfoodmenuitem` WHERE `ID`='".$SubFoodID."'";
		$Result_FoodItems2 = $db_handle->runQuery($query);
		return $Result_FoodItems2;
	}
	
	public function Select_FoodItemsMain3()
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfoodmenuitem` WHERE `FoodCatID`!=''";
		$Result_FoodItems2 = $db_handle->runQuery($query);
		return $Result_FoodItems2;
	}
	
	
	public function Select_FoodCategory()
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfoodcategory`";
		$Result_FoodCategory = $db_handle->runQuery($query);
		return $Result_FoodCategory;
	}
	public function Select_FoodCategory2($dbFoodCatID)
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfoodcategory` WHERE `ID`='".$dbFoodCatID."'";
		$Result_FoodCategory2 = $db_handle->runQuery($query);
		return $Result_FoodCategory2;
	}
	
	public function Select_Feedback()
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfeedback` ORDER BY `tblfeedback`.`ID` DESC";
		$Result_Feedbckload = $db_handle->runQuery($query);
		return $Result_Feedbckload;
	}
	
	
	public function Insert_Feedback($feedback,$name)
	{
	    $db_handle = new DBController();
		$query = "INSERT INTO `tblfeedback`(`Description`, `Username`) VALUES ('".$feedback."','".$name."')";
		$Result_Feedbck = $db_handle->insertQuery($query);
		return $Result_Feedbck;
	}
	
	
	public function Insert_OrderHead($InvoiceNo,$tableNo,$cusName,$CusAddress,$CusPhone,$CusEmail,$Totale)
	{
	    $db_handle = new DBController();
		$query = "INSERT INTO `tblorderheader`(`OrderID`, `TableNo`,`Totale`, `CusName`, `CusAddress`, `CusPhone`, `CusEmail`,`Status`)
		VALUES ('".$InvoiceNo."','".$tableNo."','".$Totale."','".$cusName."','".$CusAddress."','".$CusPhone."','".$CusEmail."','Pendding')";
		$Result_Feedbck = $db_handle->insertQuery($query);
		return $Result_Feedbck;
	}
	
	public function Insert_OrderItem($InvoiceNo,$name,$code,$quantity,$price,$img,$SubFood)
	{//$item["name"],$item["code"],$item["quantity"],$item["price"],$item["img"]
	    $db_handle = new DBController();
		$query = "	INSERT INTO `tblorderitem`(`OrderID`, `FoodCode`,`Name`, `Price`, `Qty`, `Image`, `SubfoodID`) VALUES ('".$InvoiceNo."','".$code."','".$name."','".$price."','".$quantity."','".$img."','".$SubFood."')";
		$Result_Feedbck = $db_handle->insertQuery($query);
		return $Result_Feedbck;
	}
	
	public function Insert_Registration($Name,$Phone,$Password,$email)
	{
	    $db_handle = new DBController();
		$query = "INSERT INTO `tbluser`(`Name`, `PhoneNo`, `Email`, `UserRoleID`, `Password`) VALUES ('".$Name."','".$Phone."','".$email."','3','".$Password."')";
		$Result_Registration = $db_handle->insertQuery($query);
		return $Result_Registration;
	}
	public function Search_FoodItemsMain($txtsearch,$categoryID,$FoodType)
	{
	    $db_handle = new DBController();
		$query = "SELECT * FROM `tblfoodmenuitem` WHERE `FoodName` LIKE '%$txtsearch%' AND `FoodType`='".$FoodType."' AND `FoodCatID`='".$categoryID."'";
		//echo 'aaaa - '.$query;
		$Result_SearchFoodItems = $db_handle->insertQuery($query);
		return $Result_SearchFoodItems;
	}
	
	

	
	
}

?>