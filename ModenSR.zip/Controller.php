<?php 
session_start(); 
require_once("Controller/dbcontroller.php");
$db_handle = new DBController();
?>